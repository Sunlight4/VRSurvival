This package installs the python documentation at a location
that is useable for pydoc and IDLE.
