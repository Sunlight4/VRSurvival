This package installs Python.framework, that is the python
interpreter and the standard library. This also includes Python
wrappers for lots of Mac OS X API's.
