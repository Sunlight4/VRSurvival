import os,getpass

user = getpass.getuser()

def search_and_run(searchfor=None):
    folder = "/Users/" + user + "/VSurvival/mod"
    if os.path.exists(folder):
        for fl in os.listdir(folder):
            if searchfor==None or fl==searchfor:
                flnm = folder+"/"+fl
                execfile(flnm)

def runpythonfiles():
    folder = "/Users/" + user + "/VSurvival/mod"
    
    for fl in os.listdir(folder):
        flnm = folder+"/"+fl
        execfile(flnm)
        
    

  
