import pygame

class Liquid:
    def __init__(self,name,texture):
        self.name = name
        self.texture = texture

