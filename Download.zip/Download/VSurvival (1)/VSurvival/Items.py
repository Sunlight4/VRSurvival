import ItemClass,getpass

user = getpass.getuser()

def air():
    air = ItemClass.Item("air","/Users/" + user + "/Desktop/VSurvival/images/air.png",0,1)
    return air

def apple():
    apple = ItemClass.Item("apple","/Users/" + user + "/Desktop/VSurvival/images/apple.png",0,1)
    return apple

def fish():
    fish = ItemClass.Item("fish","/Users/" + user + "/Desktop/VSurvival/images/apple.png",0,1)
    return fish

def bomb():
    bomb = ItemClass.Item("bomb","/Users/" + user + "/Desktop/VSurvival/images/bomb.png",0,1)

def secretitem():
    secretitem = ItemClass.Item("SecretItem","/Users/" + user + "/Desktop/VSurvival/images/lol.png",0,1)
    return secretitem
