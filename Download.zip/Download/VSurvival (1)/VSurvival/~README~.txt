VSurvival

A realistic, virtual survival game, similar to Minecraft

Installation

Mac OS X

Move the VSurvival Application… anywhere.

Windows

Move VSurvival.exe… anywhere


How to play

Run Application or exe.

If you downloaded a Python Package version, run main.py. Use Python 2.5
