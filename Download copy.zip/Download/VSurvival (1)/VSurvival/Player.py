import pygame

class Player:
    def __init__(self,spawnpos,username,health,hunger,thirst,temp):
        self.spawnpos = spawnpos
        self.username = username
        self.health = health
        self.hunger = hunger
        
